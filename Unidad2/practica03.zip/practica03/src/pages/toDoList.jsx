import Container from "../components/Container.jsx";
import "../styles/toDoList.css";

export default function Test() {
  return (
    <>
      <h1>To-Do List</h1>
      <div className="App">
        <Container />
      </div>
    </>
  );
}
